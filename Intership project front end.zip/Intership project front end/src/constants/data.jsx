import { assets } from "../assets/assets";
import { RiDashboardLine, RiUserLine, RiFileTextLine, RiShieldUserLine, RiSettingsLine } from "react-icons/ri";
import { TbLogs } from "react-icons/tb";
import { IoMdMore } from "react-icons/io";

export const features = [
    {
        title: "Lightning Fast Creation",
        description: "Generate high-quality blog posts in minutes, not hours. Our AI understands your style and tone.",
        icon: "⚡",
        gradient: "from-purple-500 to-pink-500"
    },
    {
        title: "Intelligent Content",
        description: "Advanced AI algorithms ensure your content is engaging, SEO-optimized, and tailored to your audience.",
        icon: "🧠",
        gradient: "from-blue-500 to-indigo-600"
    },
    {
        title: "Privacy First",
        description: "Your data is secure. We don't store your personal information or share your content with third parties.",
        icon: "🔒",
        gradient: "from-emerald-500 to-teal-600"
    },
    {
        title: "Developer Friendly",
        description: "Built by developers, for developers. Seamless integration with your existing workflow and tools.",
        icon: "💻",
        gradient: "from-amber-500 to-orange-500"
    },
    {
        title: "Community Driven",
        description: "Join thousands of creators who trust CodeScribe AI for their content creation needs.",
        icon: "👥",
        gradient: "from-rose-500 to-pink-600"
    },
    {
        title: "Professional Quality",
        description: "Every blog post meets professional standards with proper formatting, structure, and readability.",
        icon: "🏆",
        gradient: "from-violet-500 to-purple-600"
    }
];


export const stats = [
    { value: "50K+", label: "Active Users", icon: "👥" },
    { value: "99.9%", label: "Uptime", icon: "⏱️" },
    { value: "1M+", label: "Blogs Created", icon: "✍️" },
    { value: "24/7", label: "Support", icon: "🛟" }
];



export const teamMembers = [
    {
        name: "Soumita Paul",
        role: "Backend Enginner",
        image: assets.shoumitaPaulImage,
        gitHub: 'https://github.com/soumita-paul-90',
        linkdin: 'https://www.linkedin.com/in/soumita-paul-a5b5b2292?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
    },
    {
        name: "Arindom Pal",
        role: "Backend Enginner",
        image: assets.arindomPaulImage,
        gitHub: 'https://github.com/MrPal28',
        linkdin: 'https://www.linkedin.com/in/arindam-pal-977318291',
    },
    {
        name: "Soumyadip Adak",
        role: "Full Stack Developer",
        image: assets.soumyadipAdakImage,
        gitHub: 'https://github.com/soumyadip-adak99',
        linkdin: 'https://www.linkedin.com/in/soumyadip-adak-a19b03281/',
    },
    {
        name: "Aritra Das",
        role: "Backend Engineer",
        image: assets.aritraDasImage,
        gitHub: 'https://github.com/Aritra7636',
        linkdin: 'https://www.linkedin.com/in/aritra-das-a69897212?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
    },
    {
        name: "Aritra Naskar",
        role: "Backend Enginner",
        image: assets.aritraNaskarImage,
        gitHub: 'https://guthub.com',
        linkdin: 'https://linkedin.com',
    }
];


export const adminNavItems = [
    {
        icon: <RiDashboardLine className="text-xl" />,
        label: "Dashboard",
        path: "/admin/dashboard"
    },
    {
        icon: <RiUserLine className="text-xl" />,
        label: "Users",
        path: "/admin/users"
    },
    {
        icon: <TbLogs className="text-xl" />,
        label: "Blogs",
        path: "/admin/blogs"
    },
    {
        icon: <IoMdMore className="text-xl" />,
        label: "More",
        path: "/admin/more"
    },
];
