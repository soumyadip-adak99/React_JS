function Navbar({ profileImage }) {
    return (
        <div>
            <nav>
                
            </nav>
        </div>
    )
}

export default Navbar