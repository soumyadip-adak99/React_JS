import { useState } from 'react';
import { FiEdit, FiTrash2, FiMoreVertical, FiChevronDown, FiChevronUp } from 'react-icons/fi';

function Dashboard() {
    const demoUserData = [
        {
            "id": "507f1f77bcf86cd799439011",
            "firstname": "John",
            "lastname": "Doe",
            "email": "john.doe@example.com",
            "phoneNumber": "+1234567890",
            "password": "$2a$10$N9qo8uLOickgx2ZMRZoMy.MrUvZkg4X7Vn.H7vCw6XJ5Jz5Y5zY5K",
            "role": ["ROLE_USER"],
            "profileImage": {
                "id": "img12345",
                "url": "https://example.com/profile/john.jpg"
            },
            "userStatus": "ACTIVE",
            "blogEntries": [
                {
                    "id": "65f3a1b8c8b9c12a5c8e7f1a",
                    "title": "My First Blog Post",
                    "content": "This is my first blog post..."
                }
            ],
            "createdAt": "2023-05-15T10:30:45"
        },
        {
            "id": "507f1f77bcf86cd799439012",
            "firstname": "Jane",
            "lastname": "Smith",
            "email": "jane.smith@example.com",
            "phoneNumber": "+1987654321",
            "password": "$2a$10$N9qo8uLOickgx2ZMRZoMy.MrUvZkg4X7Vn.H7vCw6XJ5Jz5Y5zY5K",
            "role": ["ROLE_USER", "ROLE_ADMIN"],
            "profileImage": {
                "id": "img67890",
                "url": "https://example.com/profile/jane.jpg"
            },
            "userStatus": "ACTIVE",
            "blogEntries": [
                {
                    "id": "65f3a1b8c8b9c12a5c8e7f1b",
                    "title": "Spring Boot Tutorial",
                    "content": "In this post, I'll explain Spring Boot basics..."
                },
                {
                    "id": "65f3a1b8c8b9c12a5c8e7f1c",
                    "title": "MongoDB Best Practices",
                    "content": "Here are some MongoDB tips I've learned..."
                }
            ],
            "createdAt": "2023-06-20T14:15:22"
        },
        {
            "id": "507f1f77bcf86cd799439013",
            "firstname": "Alex",
            "lastname": "Johnson",
            "email": "alex.j@example.com",
            "phoneNumber": "+1122334455",
            "password": "$2a$10$N9qo8uLOickgx2ZMRZoMy.MrUvZkg4X7Vn.H7vCw6XJ5Jz5Y5zY5K",
            "role": ["ROLE_USER"],
            "profileImage": null,
            "userStatus": "PENDING",
            "blogEntries": [],
            "createdAt": "2023-07-10T09:05:33"
        },
        {
            "id": "507f1f77bcf86cd799439014",
            "firstname": "Admin",
            "lastname": "User",
            "email": "admin@example.com",
            "phoneNumber": "+1555666777",
            "password": "$2a$10$N9qo8uLOickgx2ZMRZoMy.MrUvZkg4X7Vn.H7vCw6XJ5Jz5Y5zY5K",
            "role": ["ROLE_ADMIN", "ROLE_SUPER_ADMIN"],
            "profileImage": {
                "id": "imgadmin1",
                "url": "https://example.com/profile/admin.jpg"
            },
            "userStatus": "ACTIVE",
            "blogEntries": [
                {
                    "id": "65f3a1b8c8b9c12a5c8e7f1d",
                    "title": "Admin Announcement",
                    "content": "Important system update coming soon..."
                }
            ],
            "createdAt": "2023-01-05T08:00:00"
        }
    ]

    const demoBlogData = [
        {
            "id": "65f3a1b8c8b9c12a5c8e7f1a",
            "title": "Getting Started with Spring Boot",
            "authorName": "John Doe",
            "content": "Spring Boot makes it easy to create stand-alone, production-grade Spring based Applications that you can 'just run'...",
            "createdDate": "2023-05-15T10:30:45",
            "isAiApproved": true,
            "status": "PUBLISHED"
        },
        {
            "id": "65f3a1b8c8b9c12a5c8e7f1b",
            "title": "MongoDB Best Practices",
            "authorName": "Jane Smith",
            "content": "When working with MongoDB, there are several best practices to follow for optimal performance...",
            "createdDate": "2023-06-20T14:15:22",
            "isAiApproved": false,
            "status": "DRAFT"
        },
        {
            "id": "65f3a1b8c8b9c12a5c8e7f1c",
            "title": "Microservices Architecture Patterns",
            "authorName": "Alex Johnson",
            "content": "Microservices architecture has become increasingly popular. Here are the key patterns you should know...",
            "createdDate": "2023-07-10T09:05:33",
            "isAiApproved": true,
            "status": "PUBLISHED"
        },
        {
            "id": "65f3a1b8c8b9c12a5c8e7f1d",
            "title": "React Hooks Explained",
            "authorName": "Sarah Williams",
            "content": "React Hooks allow you to use state and other React features without writing classes...",
            "createdDate": "2023-08-05T16:45:10",
            "isAiApproved": true,
            "status": "PENDING_REVIEW"
        },
        {
            "id": "65f3a1b8c8b9c12a5c8e7f1e",
            "title": "DevOps CI/CD Pipeline",
            "authorName": "Michael Brown",
            "content": "Setting up an efficient CI/CD pipeline is crucial for modern software development...",
            "createdDate": "2023-09-12T11:20:05",
            "isAiApproved": false,
            "status": "ARCHIVED"
        }
    ]
    const [users, setUsers] = useState(demoUserData);
    const [blogs, setBlogs] = useState(demoBlogData);
    const [editUser, setEditUser] = useState(null);
    const [editBlog, setEditBlog] = useState(null);
    const [showUserForm, setShowUserForm] = useState(false);
    const [showBlogForm, setShowBlogForm] = useState(false);
    const [userSortDesc, setUserSortDesc] = useState(true);
    const [blogSortDesc, setBlogSortDesc] = useState(true);

    // Sort users by creation date
    const sortedUsers = [...users].sort((a, b) => {
        const dateA = new Date(a.createdAt);
        const dateB = new Date(b.createdAt);
        return userSortDesc ? dateB - dateA : dateA - dateB;
    });

    // Sort blogs by creation date
    const sortedBlogs = [...blogs].sort((a, b) => {
        const dateA = new Date(a.createdDate);
        const dateB = new Date(b.createdDate);
        return blogSortDesc ? dateB - dateA : dateA - dateB;
    });

    // Get only the first 4 users/blogs
    const displayedUsers = sortedUsers.slice(0, 4);
    const displayedBlogs = sortedBlogs.slice(0, 4);

    // Handle delete
    const handleDeleteUser = (id) => {
        setUsers(users.filter(user => user.id !== id));
    };

    const handleDeleteBlog = (id) => {
        setBlogs(blogs.filter(blog => blog.id !== id));
    };

    // Handle edit
    const handleEditUser = (user) => {
        setEditUser(user);
        setShowUserForm(true);
    };

    const handleEditBlog = (blog) => {
        setEditBlog(blog);
        setShowBlogForm(true);
    };

    // Status badge component
    const StatusBadge = ({ status }) => {
        let color = "";
        switch (status) {
            case "ACTIVE": color = "bg-green-500"; break;
            case "PENDING": color = "bg-yellow-500"; break;
            case "ARCHIVED": color = "bg-gray-500"; break;
            case "PUBLISHED": color = "bg-blue-500"; break;
            case "DRAFT": color = "bg-purple-500"; break;
            default: color = "bg-gray-500";
        }
        return (
            <span className={`${color} text-white text-xs px-2 py-1 rounded-full`}>
                {status}
            </span>
        );
    };

    return (
        <div className="p-6 min-h-screen">
            {/* Heading */}
            <div className="mb-8">
                <h1 className="text-3xl text-white font-bold">Admin Dashboard</h1>
                <p className="text-gray-400">Overview and management</p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div className="bg-gray-800 rounded-lg p-6 shadow-lg">
                    <h3 className="text-gray-400 text-sm font-medium">Total Users</h3>
                    <p className="text-3xl font-bold text-white">{users.length}</p>
                </div>
                <div className="bg-gray-800 rounded-lg p-6 shadow-lg">
                    <h3 className="text-gray-400 text-sm font-medium">Total Blogs</h3>
                    <p className="text-3xl font-bold text-white">{blogs.length}</p>
                </div>
                <div className="bg-gray-800 rounded-lg p-6 shadow-lg">
                    <h3 className="text-gray-400 text-sm font-medium">Active Users</h3>
                    <p className="text-3xl font-bold text-white">
                        {users.filter(u => u.userStatus === "ACTIVE").length}
                    </p>
                </div>
                <div className="bg-gray-800 rounded-lg p-6 shadow-lg">
                    <h3 className="text-gray-400 text-sm font-medium">Published Blogs</h3>
                    <p className="text-3xl font-bold text-white">
                        {blogs.filter(b => b.status === "PUBLISHED").length}
                    </p>
                </div>
            </div>

            {/* Users Table */}
            <div className="bg-gray-800 rounded-lg shadow-lg p-6 mb-8">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-white">Recent Users</h2>
                    <button
                        onClick={() => setUserSortDesc(!userSortDesc)}
                        className="flex items-center text-gray-400 hover:text-white"
                    >
                        Sort by Date {userSortDesc ? <FiChevronDown /> : <FiChevronUp />}
                    </button>
                </div>

                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-700">
                        <thead>
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">SL No</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">User ID</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Name</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Email</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Phone</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Created</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-700">
                            {displayedUsers.map((user, index) => (
                                <tr key={user.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{index + 1}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{user.id.substring(0, 8)}...</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-white">
                                        {user.firstname} {user.lastname}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{user.email}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{user.phoneNumber}</td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <StatusBadge status={user.userStatus} />
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                                        {new Date(user.createdAt).toLocaleDateString()}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div className="flex space-x-2">
                                            <button
                                                onClick={() => handleEditUser(user)}
                                                className="text-blue-400 hover:text-blue-300"
                                            >
                                                <FiEdit />
                                            </button>
                                            <button
                                                onClick={() => handleDeleteUser(user.id)}
                                                className="text-red-400 hover:text-red-300"
                                            >
                                                <FiTrash2 />
                                            </button>
                                            <button className="text-gray-400 hover:text-white">
                                                <FiMoreVertical />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Blogs Table */}
            <div className="bg-gray-800 rounded-lg shadow-lg p-6">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-white">Recent Blogs</h2>
                    <button
                        onClick={() => setBlogSortDesc(!blogSortDesc)}
                        className="flex items-center text-gray-400 hover:text-white"
                    >
                        Sort by Date {blogSortDesc ? <FiChevronDown /> : <FiChevronUp />}
                    </button>
                </div>

                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-700">
                        <thead>
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">SL No</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Blog ID</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Title</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Author</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">AI Approved</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Created</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-700">
                            {displayedBlogs.map((blog, index) => (
                                <tr key={blog.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{index + 1}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{blog.id.substring(0, 8)}...</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{blog.title}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{blog.authorName}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                                        {blog.isAiApproved ? "Yes" : "No"}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <StatusBadge status={blog.status} />
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                                        {new Date(blog.createdDate).toLocaleDateString()}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div className="flex space-x-2">
                                            <button
                                                onClick={() => handleEditBlog(blog)}
                                                className="text-blue-400 hover:text-blue-300"
                                            >
                                                <FiEdit />
                                            </button>
                                            <button
                                                onClick={() => handleDeleteBlog(blog.id)}
                                                className="text-red-400 hover:text-red-300"
                                            >
                                                <FiTrash2 />
                                            </button>
                                            <button className="text-gray-400 hover:text-white">
                                                <FiMoreVertical />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* Edit User Modal */}
            {showUserForm && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
                        <h3 className="text-xl font-bold text-white mb-4">Edit User</h3>
                        <form>
                            <div className="mb-4">
                                <label className="block text-gray-400 text-sm mb-2">First Name</label>
                                <input
                                    type="text"
                                    defaultValue={editUser.firstname}
                                    className="w-full bg-gray-700 text-white rounded px-3 py-2"
                                />
                            </div>
                            <div className="mb-4">
                                <label className="block text-gray-400 text-sm mb-2">Last Name</label>
                                <input
                                    type="text"
                                    defaultValue={editUser.lastname}
                                    className="w-full bg-gray-700 text-white rounded px-3 py-2"
                                />
                            </div>
                            <div className="mb-4">
                                <label className="block text-gray-400 text-sm mb-2">Email</label>
                                <input
                                    type="email"
                                    defaultValue={editUser.email}
                                    className="w-full bg-gray-700 text-white rounded px-3 py-2"
                                />
                            </div>
                            <div className="flex justify-end space-x-3">
                                <button
                                    type="button"
                                    onClick={() => setShowUserForm(false)}
                                    className="px-4 py-2 text-gray-300 hover:text-white"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                                >
                                    Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Edit Blog Modal */}
            {showBlogForm && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
                        <h3 className="text-xl font-bold text-white mb-4">Edit Blog</h3>
                        <form>
                            <div className="mb-4">
                                <label className="block text-gray-400 text-sm mb-2">Title</label>
                                <input
                                    type="text"
                                    defaultValue={editBlog.title}
                                    className="w-full bg-gray-700 text-white rounded px-3 py-2"
                                />
                            </div>
                            <div className="mb-4">
                                <label className="block text-gray-400 text-sm mb-2">Content</label>
                                <textarea
                                    defaultValue={editBlog.content}
                                    className="w-full bg-gray-700 text-white rounded px-3 py-2 h-32"
                                />
                            </div>
                            <div className="mb-4">
                                <label className="block text-gray-400 text-sm mb-2">Status</label>
                                <select
                                    defaultValue={editBlog.status}
                                    className="w-full bg-gray-700 text-white rounded px-3 py-2"
                                >
                                    <option value="PUBLISHED">Published</option>
                                    <option value="DRAFT">Draft</option>
                                    <option value="PENDING_REVIEW">Pending Review</option>
                                    <option value="ARCHIVED">Archived</option>
                                </select>
                            </div>
                            <div className="flex justify-end space-x-3">
                                <button
                                    type="button"
                                    onClick={() => setShowBlogForm(false)}
                                    className="px-4 py-2 text-gray-300 hover:text-white"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                                >
                                    Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

export default Dashboard;